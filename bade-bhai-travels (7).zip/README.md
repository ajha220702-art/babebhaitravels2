# Bade Bhai Travels

A single-page demo interface for Bade Bhai Travels — live bus tracking, journey planning, and an AI-assisted route search, styled around the brand's navy, teal, and sunset-orange logo palette.

**Interactive extras:**
- **Language switcher** (top-right) — English, Tamil (தமிழ்), Telugu (తెలుగు), Hindi (हिंदी). Switches all page copy and remembers the choice for next visit.
- **"Get more from every journey" plans section** — a ₹99/month plan shown with the original ₹100 struck through, plus a demo "Subscribe" button (no real payment is taken). Subscribing also credits **5 free rides**, shown as a badge under the button that persists across reloads.
- **Interactive AI assistant chat** in "Ask it the way you'd ask a person" — type something like *"how do I get from Adyar to Velachery?"* and it matches your query against a small knowledge base modelled on real Chennai MTC-style routes (route numbers, via-stops, frequency, first/last bus) to recommend the best bus and timing. It's a rule-based demo (no external AI or live Google data call — this is a static site with no backend), but the route data is written to resemble real MTC route patterns.
- **"Book seats" section** — 6 bus routes (21G, 5C, M18, 27B, 45B, 12H), each with a couple of scheduled buses. Pick a route from the dropdown, open a bus's seat map, tap open seats to select them, and confirm — the seat count updates live and bookings persist in the visitor's own browser (same local-storage approach as the reviews).
- **Soft blue light theme**, with a larger, clearer logo in the nav bar.
- **"Share your experience" section** — visitors can leave a star rating and comment. Since this is a static site with no backend, entries are saved in the visitor's own browser (`localStorage`), so they'll see their own comments on return visits, but comments aren't shared between different visitors' devices. To make comments truly shared across everyone, you'd need a small backend or a service like Firebase/Supabase — happy to help wire that up if you want it.

## Run it locally

Just open `index.html` in any browser. No build step, no dependencies to install.

## Deploy on GitHub Pages

1. Create a new repository on GitHub (e.g. `bade-bhai-travels`).
2. Push these files (`index.html`, `logo.jpeg`, this `README.md`) to the `main` branch.
3. In the repo, go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`.
5. Save — GitHub will publish the site at `https://<your-username>.github.io/<repo-name>/` within a minute or two.

- **Real Google Maps integration** — "Plan a journey", the AI chat replies, and every bus card in "Book seats" each include a **"View live on Google Maps"** link. This opens actual Google Maps transit directions (Google's real, live bus arrival/route/destination data) for that exact origin → destination — no API key needed, since it uses Google's public maps deep-link format rather than the paid Google Maps Platform API. (A live in-page arrival feed with seat-level Google data would need a paid Google Maps Platform key kept on a private backend — not something a static GitHub Pages site can safely hold — so the deep-link approach is the secure, no-cost way to surface real Google data here.)

## Files

- `index.html` — the full page (HTML, CSS, and JS all in one file)
- `logo.jpeg` — the Bade Bhai Travels logo, used in the nav bar and browser tab icon
